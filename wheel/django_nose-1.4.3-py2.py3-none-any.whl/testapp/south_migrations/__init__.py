"""South migrations for Django 1.6 and earlier."""
