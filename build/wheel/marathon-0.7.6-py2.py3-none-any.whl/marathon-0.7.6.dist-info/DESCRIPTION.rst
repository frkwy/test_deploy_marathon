Python interface to the Mesos Marathon REST API.


